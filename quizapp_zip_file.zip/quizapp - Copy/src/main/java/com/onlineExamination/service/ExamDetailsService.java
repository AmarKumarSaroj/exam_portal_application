package com.onlineExamination.service;

import com.onlineExamination.entity.ExamDetails;

public interface ExamDetailsService {	
	

	public ExamDetails saveExamDetails(ExamDetails examDetails);
	

	

}
