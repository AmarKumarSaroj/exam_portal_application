package com.onlineExamination.service;

public interface UserService  {
	
	
}
