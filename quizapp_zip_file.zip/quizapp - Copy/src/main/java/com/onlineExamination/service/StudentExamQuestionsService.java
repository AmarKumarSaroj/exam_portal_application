///**
// * 
// */
//package com.onlineExamination.service;
//
//import com.onlineExamination.Entity.StudentExamQuestions;
//
///**
// * @author Lenovo
// *
// */
//public interface StudentExamQuestionsService {
//
// 
//
//}
