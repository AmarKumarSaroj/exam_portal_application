package com.onlineExamination.service.impl;

import org.springframework.stereotype.Service;

import com.onlineExamination.service.UserService;

@Service
public class UserServiceImpl implements UserService{
	

}
